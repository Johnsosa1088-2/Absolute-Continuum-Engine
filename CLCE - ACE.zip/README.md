# CLCE - ACE

This repository packages a public control-geometry state for **Aurelia**, a
fictional adult reference character, together with a separate technical garment
and reusable external interaction objects.

## Public state

- declared stature: **158 cm**
- active thoracic state: **T=0**
- body and garment: separate named objects
- body/garment welding: **none**
- interaction addons: piano, string instrument, representative hand tools, and
  gymnastics apparatus
- physical textile, force, pressure, friction, and torque models: **open**

## Start here

- `docs/ARCHITECTURE_PRINCIPLES.md`
- `docs/CLCE - ACE.md`
- `docs/COORDINATE_CONVENTIONS.md`
- `docs/CLAIMS_AND_LIMITATIONS.md`
- `SCENE_MANIFEST.json`

## Verify

```bash
python tools/check_public_boundary.py
python tools/verify_release.py
python examples/verify_piano_targets.py
```

The CI workflow runs the same checks on every push and pull request.

## Architecture

The body is anatomical control authority. Clothing and interaction objects are
independent addons. Contact never implies welding, and control geometry does
not imply validated material behavior.

## Publication note

A repository license still needs to be selected before public publication.
See `docs/LICENSE_SELECTION_REQUIRED.md`.
