#!/usr/bin/env python3
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SELF=Path(__file__).resolve()

parts=[
    r"\b"+"125"+r"\s*cm\b",
    "125"+"CM",
    "AURELIA"+"125",
    "Aurelia"+"\.125",
    "FACE"+"-001A",
    "PRIVATE"+"_"+"PROVENANCE",
    "/"+"mnt"+"/"+"data",
    "CONNECT"+r"\d+",
]
FORBIDDEN=[re.compile(p,re.I) for p in parts]

TEXT_EXT={".md",".json",".csv",".py",".yml",".yaml",".txt",".obj"}
fail=[]
for p in ROOT.rglob("*"):
    if not p.is_file() or p.resolve()==SELF:
        continue
    if p.suffix.lower() not in TEXT_EXT and p.name!=".gitignore":
        continue
    text=p.read_text(errors="ignore")
    for rx in FORBIDDEN:
        if rx.search(text):
            fail.append((str(p.relative_to(ROOT)),rx.pattern))
            break

if fail:
    for item in fail:
        print("FORBIDDEN:",item[0],item[1])
    raise SystemExit(1)

print("PASS: public/private boundary scrub")
