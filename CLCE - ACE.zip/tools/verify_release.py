#!/usr/bin/env python3
import csv, hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest=json.loads((ROOT/"SCENE_MANIFEST.json").read_text())
assert manifest["declared_public_stature_cm"]==158.0
assert manifest["authority_rules"]["contact_implies_weld"] is False

for a in manifest["artifacts"]:
    p=ROOT/a["path"]
    assert p.exists(), p
    assert sha256(p)==a["sha256"], p

assembly=ROOT/"artifacts"/"AURELIA_PUBLIC_158CM_BODY_GARMENT.obj"
objects=[]
v=f=l=0
with assembly.open() as fh:
    for line in fh:
        if line.startswith("o "): objects.append(line[2:].strip())
        elif line.startswith("v "): v+=1
        elif line.startswith("f "): f+=1
        elif line.startswith("l "): l+=1

assert "AURELIA_PUBLIC_158CM_T0_BODY_CONTROL" in objects
assert "AURELIA_TECH_UNITARD_ADDON_CONTROL" in objects
assert v==2650
assert f==1650
assert l==2357

with (ROOT/"artifacts"/"registries"/"PIANO_KEY_CONTROL_REGISTRY.csv").open() as fh:
    keys=list(csv.DictReader(fh))
assert len(keys)==88

meta=json.loads((ROOT/"artifacts"/"metadata"/"PUBLIC_RELEASE_METADATA.json").read_text())
assert meta["declared_public_stature_cm"]==158.0
assert meta["body_garment_assembly"]["welded"] is False
assert meta["interaction_foundation"]["force_contact_models"]=="OPEN"

print(json.dumps({
    "pass":True,
    "public_stature_cm":158.0,
    "assembly_vertices":v,
    "assembly_faces":f,
    "piano_keys":len(keys),
},indent=2))
