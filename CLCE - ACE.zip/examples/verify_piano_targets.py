#!/usr/bin/env python3
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/"examples"/"piano_fingertip_targets.json").read_text())
assert len(D["targets"])==10
assert all(t["owner_object"]=="PIANO_88KEY_CONTROL" for t in D["targets"])
assert all(t["body_vertex_owner"] is False for t in D["targets"])
assert len({t["key_id"] for t in D["targets"]})==10
print(json.dumps({"pass":True,"targets":10,"owner":"PIANO_88KEY_CONTROL"},indent=2))
