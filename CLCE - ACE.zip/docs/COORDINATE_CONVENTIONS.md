# Coordinate conventions

This repository uses one public world frame, `ATLAS_WORLD`.

## Axes

- **Y** — vertical axis.
- **X** — bilateral/lateral axis. `POSX` and `NEGX` are geometric side labels.
- **Z** — depth axis.

The public release does **not** promote a positive-Z/negative-Z anatomical
anterior/posterior convention. Object-local forward/action directions must be
declared in the relevant interface record.

`POSX` and `NEGX` are intentionally not relabeled as anatomical left/right.
Consumers that require anatomical left/right must provide an explicit mapping.

## Public stature and scale

Declared public stature: **158 cm**.

The body control cage has a vertical Y-span of `19.782233528` public
control units, giving a public registration of approximately
`7.986964656 cm / control-unit`.

This registration is for public control-space placement. It does not make every
local radius, clearance, or control offset a measured anatomical dimension.

## Transforms

Scene-level transforms are stored in `SCENE_MANIFEST.json`.

Each object keeps its source geometry unchanged. Assembly transforms must be
represented as object transforms rather than silently rewriting source
vertices.

## Authority

- Body geometry is anatomical control authority.
- Garment geometry is an independent addon.
- Instruments, tools, and apparatus are external objects.
- A contact target is not a welded vertex.
