# Release claims and limitations

| Topic | Claim | Status | Boundary |
|---|---|---|---|
| Public stature | 158 cm presentation state | **IMPLEMENTED** | — |
| Whole-body control topology | Connected control topology | **GEOMETRICALLY_VALIDATED** | Not canonical physical skin |
| Body control-face intersections | Zero in frozen public body control topology | **GEOMETRICALLY_VALIDATED** | Nonadjacent-face test |
| Body/garment object ownership | Separate named objects; no welding | **GEOMETRICALLY_VALIDATED** | — |
| Garment four-state topology | Neutral / arm raise / seated / stride remain crossing-clean | **GEOMETRICALLY_VALIDATED** | Kinematic control states only |
| Garment material response | Thickness, modulus, anisotropy, damping, friction | **OPEN** | Control ratios are not material strain |
| Piano interaction | 88 independent key controls + bench/pedal witnesses | **IMPLEMENTED** | Key force/spring physics open |
| String instrument interaction | Bilateral hand/support frames | **IMPLEMENTED** | Force model open |
| Tool interaction | Power / cylindrical / precision / tripod grip witnesses | **IMPLEMENTED** | Torque/force model open |
| Gymnastics interaction | Beam / bar / rings / floor support witnesses | **IMPLEMENTED** | Load/contact physics open |
| Signed contact / pressure / friction | Body-garment and object-body physics | **OPEN** | — |
| Provisional surface regions | Neck, abdomen/lower trunk, gluteal, external pelvic/perineal | **PROVISIONAL** | Not promoted by clothing |
