# License selection required before publication

No repository license has been selected in this package.

Before making the repository public, choose and add an explicit license for:

1. source code and verification scripts;
2. geometry/control artifacts;
3. documentation.

Do not assume that a code license automatically grants redistribution rights to
third-party reference material. Private research references are not included in
this public package.
