# Architecture principles

Atomic Atlas / LightBench separates **what was observed**, **what was modeled**,
and **what was validated**.

1. **Body is authority.** Clothing and external objects never overwrite covered
   or contacted body geometry.
2. **Addons stay independent.** Garments, instruments, tools, and apparatus are
   separate objects with their own hashes, frames, and validation.
3. **Observation is not measurement.** A visual reference may constrain
   topology or appearance without becoming metric ground truth.
4. **Control geometry is not material behavior.** A control offset, control-edge
   ratio, or contact frame is not automatically skin thickness, fabric strain,
   force, pressure, friction, or modulus.
5. **Validation promotes claims one gate at a time.** A clean topology test does
   not imply validated dynamics; a kinematic test does not imply validated
   force or material response.
6. **Source artifacts are immutable.** New experiments derive from frozen
   artifacts rather than rewriting them.
7. **Contact is not weld.** Independent objects may touch, slide, separate, or
   transfer force while remaining topologically separate.
8. **Provisional stays provisional.** Covering or interacting with a region does
   not promote unresolved geometry to canonical status.
9. **Public/private boundaries are enforced automatically.** Public release
   artifacts must not include private reference files, private provenance, or
   development-history identifiers.

These principles make the repository reproducible without requiring access to
private research references.
